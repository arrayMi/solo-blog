title: 配置https证书时nginx 提示the "ssl" directive is deprecated
date: '2019-12-09 23:42:23'
updated: '2019-12-09 23:50:01'
tags: [nginx, https]
permalink: /articles/2019/12/09/1575906142977.html
---
![](https://img.hacpai.com/bing/20190323.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 配置https证书时nginx 提示the "ssl" directive is deprecated  
  

```
server {
     #SSL 访问端口号为 443
     listen 443; 
     #填写绑定证书的域名
     server_name www.domain.com; 
     #启用 SSL 功能
     ssl on;
     #证书文件名称
     ssl_certificate 1_www.domain.com_bundle.crt; 
     #私钥文件名称
     ssl_certificate_key 2_www.domain.com.key; 
     ssl_session_timeout 5m;
     #请按照以下协议配置
     ssl_protocols TLSv1 TLSv1.1 TLSv1.2; 
     #请按照以下套件配置，配置加密套件，写法遵循 openssl 标准。
     ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE; 
     ssl_prefer_server_ciphers on;
     location / {
        #网站主页路径。此路径仅供参考，具体请您按照实际目录操作。
         root /var/www/www.domain.com; 
         index  index.html index.htm;
     }
 }

```

在使用如上配置给nginx添加腾讯云提供的https证书后，使用

```
./nginx -s reload

```

重新加载配置文件时出现该错误，原因是新版nginx采用新的方式进行监听https请求。 通过以下方式进行修改，消除警告。

```
server {
        listen 443 ssl ;
}

```

同时删除配置中的 ssl on，效果如下图所示：![alt](https://www.eggsl.cn/upload/2019/12/4u5td7h1i4jb7rgei931grk5t9.png)
