title: Vagrant 2.2.6 无法使用VirtualBox 6.1解决办法
date: '2019-12-12 23:08:05'
updated: '2019-12-12 23:17:05'
tags: [Vagrant, 虚拟机, VirtualBox]
permalink: /articles/2019/12/12/1576163284783.html
---
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;之前一直使用```vagrant```来管理```VirtualBox```的，结果前段时间VirtualBox被自动升到6.1了，然后在使```vagrant up```来启动之前配置好的centos7的时候报了如下错误：
![image.png](https://img.hacpai.com/file/2019/12/image-03556d98.png)

```
The provider 'virtualbox' that was requested to back the machine
'default' is reporting that it isn't usable on this system. The
reason is shown below:

Vagrant has detected that you have a version of VirtualBox installed
that is not supported by this version of Vagrant. Please install one of
the supported versions listed below to use Vagrant:

4.0, 4.1, 4.2, 4.3, 5.0, 5.1, 5.2, 6.0

A Vagrant update may also be available that adds support for the version
you specified. Please check www.vagrantup.com/downloads.html to download
the latest version.
```
提示我到官网去下载最新的```vagrant```，但是我发现官网上最新版就是2.2.6，和我本地装的是一样的。
于是我又尝试重新初始化了一个centos8，使用```vagrant up```来启动，结果竟然又报了一个新的错误：
![image.png](https://img.hacpai.com/file/2019/12/image-217bd277.png)


```
PS G:\virtualBox\centos8> vagrant up
No usable default provider could be found for your system.

environments. Examples are VirtualBox, VMware, Hyper-V.

The easiest solution to this message is to install VirtualBox, which
is available for free on all major platforms.

If you believe you already have a provider available, make sure it
is properly installed and configured. You can see more details about
why a particular provider isn't working by forcing usage with
`vagrant up --provider=PROVIDER`, which should give you a more specific
error message for that particular provider.
```
提示我本地没有可用的虚拟机，感觉瞬间就懵逼了，在控制面板中明明可以看到安装的VirtualBox，感觉走进了死胡同，万幸的是天无绝人之路，在官网上还是找到了点蛛丝马迹：
![image.png](https://img.hacpai.com/file/2019/12/image-8289c628.png)
通过该链接点到vagrant在github上的仓库，灵机一动去查看了issue，果然有人和我遇到了同样的问题，并且神通广大的网友给出了解决方案。
https://github.com/oracle/vagrant-boxes/issues/178
我参考上面的步骤进行了如下操作：

1.进入我的vagrant安装目录```D:\HashiCorp\Vagrant```(ps:默认安装在c盘的这个目录下，我安装时只修改了盘符)
2.修改```D:\HashiCorp\Vagrant\embedded\gems\2.2.6\gems\vagrant-2.2.6\plugins\providers\virtualbox\plugin.rb```文件。在61行左右，添加
````autoload :Version_6_1, File.expand_path("../driver/version_6_1", __FILE__)````

![image.png](https://img.hacpai.com/file/2019/12/image-d9e4175f.png)
记住使用管理权限修改。
3.修改```D:\HashiCorp\Vagrant\embedded\gems\2.2.6\gems\
vagrant2.2.6\plugins\providers\virtualbox\driver\meta.rb```文件，在66行左右增加````"6.1" => Version_6_1,````,修改后如下图：

![image.png](https://img.hacpai.com/file/2019/12/image-b2c18a2a.png)

同时在当前目录下新建```version_6_1.rb```文件，文件内容如下：
```
require File.expand_path("../version_6_0", __FILE__)

module VagrantPlugins
  module ProviderVirtualBox
    module Driver
      # Driver for VirtualBox 6.1.x
      class Version_6_1 < Version_6_0
        def initialize(uuid)
          super

          @logger = Log4r::Logger.new("vagrant::provider::virtualbox_6_1")
        end
      end
    end
  end
end
```
到这里就结束了，然后尝试启动centos7，启动成功：

![image.png](https://img.hacpai.com/file/2019/12/image-75dba06d.png)

总结：在我们使用一些开源工具的时候，如果遇到自己搞不定的问题时，可以去github上看看issue，也许有意外惊喜。




