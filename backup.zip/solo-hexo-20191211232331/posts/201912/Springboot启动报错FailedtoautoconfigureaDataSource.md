title: Spring boot 启动报错 Failed to auto-configure a DataSource
date: '2019-12-10 19:39:27'
updated: '2019-12-10 19:39:56'
tags: [SpringBoot]
permalink: /articles/2019/12/10/1575977967520.html
---
![](https://img.hacpai.com/bing/20180117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

&nbsp;&nbsp;&nbsp;&nbsp;今天 Spring Boot 2.0 正式版发布，寻思着搭个小 demo 尝试一下 Spring Boot 的新特性，使用 idea 创建项目。在选择组件时添加了 MySQL、MyBatis 然后在第一次启动的时候启动报错，错误信息如下：

```
***************************  
APPLICATION FAILED TO START  
***************************  
Description:  
Failed to auto-configure a DataSource: 'spring.datasource.url' is not specified and no embedded datasource could be auto-configured.  
Reason: Failed to determine a suitable driver class  
Action:  
Consider the following:  
If you want an embedded database (H2, HSQL or Derby), please put it on the classpath.  
  
If you have database settings to be loaded from a particular profile you may need to activate it (no profiles are currently active).
```

&nbsp;&nbsp;&nbsp;&nbsp;经过查阅官方文档，发现需要在启动类的`@EnableAutoConfiguration`或`@SpringBootApplication`中添加  `exclude= {DataSourceAutoConfiguration.class}` ，排除此类的 autoconfig。启动以后就可以正常运行。

&nbsp;&nbsp;&nbsp;&nbsp;这是因为添加了数据库组件，所以 autoconfig 会去读取数据源配置，而我新建的项目还没有配置数据源，所以会导致异常出现。
示例如下：
```
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class FlywayDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlywayDemoApplication.class, args);
    }

}
```
