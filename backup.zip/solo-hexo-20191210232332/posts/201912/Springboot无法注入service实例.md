title: Spring boot 无法注入service实例
date: '2019-12-10 19:49:11'
updated: '2019-12-10 19:54:22'
tags: [SpringBoot]
permalink: /articles/2019/12/10/1575978551524.html
---
![](https://img.hacpai.com/bing/20190725.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

SpringBoot项目的Bean装配默认规则是根据Application类所在的包位置从上往下扫描！ 
**Application类**是指SpringBoot项目入口类。
这个类的位置很关键： 
如果Application类所在的包为：com.boot.app，则只会扫描`com.boot.app`包及其所有子包，如果service或dao所在包不在`com.boot.app`及其子包下，则不会被扫描！ 
即, 把`Application`类放到dao、service所在包的上级 `com.boot.Application` 
知道这一点非常关键，大多数情况下bean无法注入进来都是这个原因引起的。
附上正确目录结构。

![20180211152859806.png](https://img.hacpai.com/file/2019/12/20180211152859806-97614e4e.png)

