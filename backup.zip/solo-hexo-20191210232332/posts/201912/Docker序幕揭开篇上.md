title: Docker序幕揭开篇（上）
date: '2019-12-10 22:32:31'
updated: '2019-12-10 22:36:15'
tags: [Docker]
permalink: /articles/2019/12/10/1575988351384.html
---
![](https://img.hacpai.com/bing/20181125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

都 2019 年了，作为一个开发，如果你还没有听说个 Docker，那可就 out 啦，从今天开始就让我们进入 docker 的世界去感受它让无数企业为之倾倒的魅力吧。本系列的教程预估会分为以下几个章节进行阐述：

* 序幕揭开篇
* 灵魂探讨篇
* 精髓剖析篇
* 项目实战篇
* 深度提升篇

每个章节可能会分为多个小节进行描述，力求呈现出通俗易懂、深入浅出的在最短时间内让读者理解和掌握最关键的技术点。并且配合操作案例，给读者提供真正可以上手的实战指南。

接下来进入我们的第一个章节-----序幕揭开篇

***01  初识 Docker***

1.1  What  is  Docker

**1.1.1 官网首页**

[https://www.docker.com/](https://www.docker.com/)



Modernize your applications, accelerate innovation Securely build, share and run modern applications anywhere.
*翻译过来就是：使你的应用程序更加的现代化，能够在任何地方安全快速的构建、共享和运行。* 


**1.1.2** **Docs**

[https://docs.docker.com/get-started/](https://docs.docker.com/get-started/)


Docker is a platform for developers and sysadmins to develop, deploy, and run applications with containers.
The use of Linux containers to deploy applications is called containerization. Containers are not new,
but their use for easily deploying applications is.
*翻译过来是就是：Docker是一个为开发人员、系统管理人员使用容器去开发、部署或者运行应用程序的一个平台。使用linux容器去部署应用服务被称为容器化。容器不是一个新的概念，但是docker能让你更轻松的去部署应用。*


**1.1.3 不理解，我太难了**

对于官方的一些说辞，可能读起来比较晦涩，但是我们可以通过现实生产中的真实场景来加深对这些概念的理解。

- 远古时代

  ![1.jpg](https://img.hacpai.com/file/2019/12/1-27869ca7.jpg)

  问题 ：成本高、部署慢、浪费资源、硬件限制、不利于迁移扩展

* 虚拟化时代

  ![2.jpg](https://img.hacpai.com/file/2019/12/2-7162e9da.jpg)

  优点 ：相对利用好资源，相对容易扩展等。

  缺点 ：虚拟机太重了，一上来占用较多物理资源，移植性差，资源利用率低等。

- 容器时代

  ![3.jpg](https://img.hacpai.com/file/2019/12/3-d6df64f6.jpg)

   <br/>

**1.1.4 再次理解 Docker**


Docker is a platform for developers and sysadmins to develop, deploy, and run applications with containers.
The use of Linux containers to deploy applications is called containerization. Containers are not new, but their use for easily deploying applications is.
*翻译过来是就是：Docker是一个为开发人员、系统管理人员使用容器去开发、部署或者运行应用程序的一个平台。使用linux容器去部署应用服务被称为容器化。容器不是一个新的概念，但是docker能让你更轻松的去部署应用。*


发现还是比较容易理解的，但是这里有一句“Containers are not new ”，也就是容器化技术很早就 出现了，比如常见的容器化技术有 OpenVZ，LXC，RKT 等.

**1.1.5  Docker 的优势和应用场景**

[www.docker.com](http://www.docker.com) ---&gt;Solutions

(1)有助于 Microservices 的落地和部署

(2)充分利用物理机资源，同时能够整合服务器资源

(3)提高开发效率，测试效率，部署效率，有利于 DevOps 的落地，CICD

(4)云原生落地，应用更好地迁移

**1.2 What is Image and Container? **

**1.2.1 What is Image?**

Why is docker?-&gt; [What is a container](https://www.docker.com/resources/what-container)

A Docker container image is a lightweight, standalone, executable package of software that includes everything needed to run an application: code, runtime, system tools, system libraries and settings.
*翻译过来就是：Docker容器镜像是轻巧的，独立的，可执行的软件包，其中包括运行应用程序所需的一切：代码，运行时，系统工具，系统库和设置。*


**1.2.2** **What** **is** **Container？**

Why is docker?-&gt; [What is a container](https://www.docker.com/resources/what-container)


A container is a standard unit of software that packages up code and all its dependencies so the application runs quickly and reliably from one computing environment to another.
*翻译过来就是：容器是打包代码及其所有依赖组件的标准软件单元，因此应用程序可以从一太机器环境快速可靠地运行到另一个机器环境。*



**1.2.3** **Relation** **between** **image** **and** **container**


Container images become containers at runtime and in the case of Docker containers- images become containers when they run on Docker Engine.
*翻译过来就是：容器镜像在运行时成为容器，对于Docker容器，镜像在Docker Engine上运行时成为容器。*


**1.2.4** **View** **from** **Docs**

从帮助文档的角度看

[docker](http://www.docker.com/)[官网](http://www.docker.com/)-&gt;Resources-&gt;Docs-&gt;Get started-&gt;Get started with Docker-&gt;Orientation-&gt;Images and containers


A container is launched by running an image. An image is an executable package that includes everything needed to run an application--the code, a runtime, libraries, environment variables, and configuration files.
A container is a runtime instance of an image--what the image becomes in memory when executed (that is, an image with state, or a user process). You can see a list of your running containers with the command, docker ps, just as you would in Linux.


**1.3** **Containers** **and** **virtual** **machines**

docker 官网]([www.docker.com](http://www.docker.com/))-&gt;Resources-&gt;Docs-&gt;Get started-&gt;Get started with Docker- &gt;Orientation-&gt;Containers and virtual machines


A container runs natively on Linux and shares the kernel of the host machine with other containers. It runs a discrete process, taking no more memory than any other executable, making it lightweight.

By contrast, a virtual machine (VM) runs a full-blown “guest” operating system with virtual access to host resources through a hypervisor. In general, VMs incur a lot of overhead beyond what is being consumed by your application logic.

<img src="https://img.hacpai.com/file/2019/12/Container2x-1a9f08e0.png" style="zoom:33%;" />
<img src="https://img.hacpai.com/file/2019/12/VM2x-97403df8.png" style="zoom:33%;" />

<br/><br/>

**1.4 Docker Engine and Architecture**

[https://docs.docker.com/engine/docker-overview/](https://docs.docker.com/engine/docker-overview/)[ ](https://docs.docker.com/engine/docker-overview/)

**1.4.1** **Docker** **Engine**

*Docker* *Engine* is a client-server application with these major components:

* server which is a type of long-running program called a daemon process (the dockerd command).
* REST API which speci ﬁ es interfaces that programs can use to talk to the daemon and instruct it what to do.
* command line interface (CLI) client (the docker command).

  ![enginecomponentsflow.png](https://img.hacpai.com/file/2019/12/enginecomponentsflow-40380d77.png)

<br/><br/>

**1.4.2** **Docker** **Architecture**


Docker uses a client-server architecture. The Docker client talks to the Docker daemon, which does the heavy lifting of building, running, and distributing your Docker containers. The Docker client and daemon can run on the same system, or you can connect a Docker client to a remote Docker daemon. The Docker client and daemon communicate using a REST API, over UNIX sockets or a network interface.


![architecture.png](https://img.hacpai.com/file/2019/12/architecture-e624b07e.png)

<br/><br/>

**1.5 Install and Experience**

[https://docs.docker.com/install/linux/docker-ce/centos/](https://docs.docker.com/install/linux/docker-ce/centos/)

![4.jpg](https://img.hacpai.com/file/2019/12/4-ce75dbbc.jpg)

好了，今天的目标到这里就结束了，我们了解到了 docker 核心概念---镜像和容器，以及在生产中 docker 能够带给我们的便利，在下一章节我将会给大家分享 docker 的安装以及运行我们的第一个容器化的 Hello world 程序。
